#include <stdio.h>

int main()
{
    int i;
    float hours, regularHours, overtimeHours;
    float regularPay = 100, overtimePay = 200;
    float totalRegular = 0, totalOvertime = 0, totalSalary = 0;

    for (i = 1; i <= 7; i++)
    {
        printf("Enter working hours for Day %d: ", i);
        scanf("%f", &hours);

        if (hours > 8)
        {
            regularHours = 8;
            overtimeHours = hours - 8;
        }
        else
        {
            regularHours = hours;
            overtimeHours = 0;
        }

        totalRegular += regularHours * regularPay;
        totalOvertime += overtimeHours * overtimePay;
    }

    totalSalary = totalRegular + totalOvertime;

    printf("\nWeekly Payroll Summary \n");
    printf("Regular Pay  : ₹%.2f\n", totalRegular);
    printf("Overtime Pay : ₹%.2f\n", totalOvertime);
    printf("Total Salary : ₹%.2f\n", totalSalary);

    return 0;
}
