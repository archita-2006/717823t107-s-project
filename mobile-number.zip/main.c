#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
    char mobile[20];
    int i, valid = 1;

    printf("Enter mobile number: ");
    scanf("%s", mobile);

    if (strlen(mobile) != 10)
    {
        printf("Invalid: Mobile number must contain exactly 10 digits.\n");
        valid = 0;
    }

    if (mobile[0] == '0')
    {
        printf("Invalid: Mobile number should not start with 0.\n");
        valid = 0;
    }

    for (i = 0; mobile[i] != '\0'; i++)
    {
        if (!isdigit(mobile[i]))
        {
            printf("Invalid: Mobile number must contain digits only.\n");
            valid = 0;
            break;
        }
    }

    if (valid == 1)
    {
        printf("Valid mobile number.\n");
    }

    return 0;
}
