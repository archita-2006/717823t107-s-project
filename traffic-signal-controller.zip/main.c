#include <stdio.h>

int main()
{
	int i;

	while (i>0)
	{

		printf("\n--- RED SIGNAL ---\n");
		for (i = 10; i >= 1; i--)
		{
			printf("RED : %d\n", i);
		}
		printf("\n--- YELLOW SIGNAL ---\n");
		for (i = 3; i >= 1; i--)
		{
			printf("YELLOW : %d\n", i);
		}

		printf("\n--- GREEN SIGNAL ---\n");
		for (i = 7; i >= 1; i--)
		{
			printf("GREEN : %d\n", i);
		}
	}

	return 0;
}
