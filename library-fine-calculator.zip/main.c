#include <stdio.h>

int main()
{
    int days;
    float fine = 0;

    printf("Enter number of days overdue: ");
    scanf("%d", &days);

    printf("\n Fine Calculation Details \n");

    if (days <= 0)
    {
        printf("No fine. Book returned on time.\n");
    }
    else if (days >= 1 && days <= 5)
    {
        fine = days * 2;
        printf("Days overdue : %d days\n", days);
        printf("Fine rate    : ₹2 per day\n");
        printf("Total fine   : ₹%.2f\n", fine);
    }
    else if (days >= 6 && days <= 10)
    {
        fine = days * 5;
        printf("Days overdue : %d days\n", days);
        printf("Fine rate    : ₹5 per day\n");
        printf("Total fine   : ₹%.2f\n", fine);
    }
    else
    {
        fine = days * 10;
        printf("Days overdue : %d days\n", days);
        printf("Fine rate    : ₹10 per day\n");
        printf("Total fine   : ₹%.2f\n", fine);

        if (days > 30)
        {
            printf("\n MEMBERSHIP CANCELLED \n");
        }
    }

    return 0;
}
