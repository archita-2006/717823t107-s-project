/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int age,travel_distance;
    char passenger_name[50];
    printf ("passenger_name :");
    scanf("%c",&passenger_name);
     printf ("\nAge :");
    scanf("%d",&age);
     printf ("\ntravel_distance :");
    scanf("%d",&travel_distance);
    int ticket_price = travel_distance *3;
    printf("\n",ticket_price);
    
    

    return 0;
}
